from flask import Flask,render_template,request
import mysql.connector

app = Flask(__name__)


connection=mysql.connector.connect(host='localhost',user='root',password='',database='mst_jan')
mycursor=connection.cursor()
datab = {'susmin':'1234'}


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/sample',methods=['GET','POST'])
def login():
    username = request.form['textbox1']
    pwd = request.form['textbox2']
    if username not in datab:
        return render_template('/index.html',msg='Invalid username')
    elif datab[username] !=pwd:
        return render_template('/index.html',msg='invalid password')
    else:
        return render_template('/home.html')
    
@app.route('/read',methods=['GET','POST'])
def read():
    if request.method=='POST':
        id=request.form.get('id')
        name=request.form.get('name')
        brand=request.form.get('brand')
        expdate=request.form.get('expdate')


        query="INSERT INTO resta(`id`, `name`, `brand`, `expdate`) VALUES (%s,%s,%s,%s)"
        data=(id,name,brand,expdate)
        mycursor.execute(query,data)
        connection.commit()
        
        return render_template('/home.html')

@app.route('/viewall')
def viewall():
    query="Select * from resta"
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('/viewall.html',sqldata=data)

@app.route('/search')
def search():
    return render_template('/search.html')

@app.route('/searchresult',methods=['GET','POST'])
def searchresult():
    if request.method=='POST':
        id=request.form.get('id')
    query="SELECT * FROM resta WHERE ID="+id
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('/viewall.html',sqldata=data)

if __name__=='__main__':
    app.run(debug=True,port=5100)