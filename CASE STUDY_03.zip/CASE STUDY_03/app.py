from flask import Flask,render_template
app = Flask(__name__)

@app.route('home.html')
def home():
    return render_template('home.html')

@app.route('courses.html')
def about():
    return render_template('courses.html')

if __name__=='__main__':
    app.run(debug=True)